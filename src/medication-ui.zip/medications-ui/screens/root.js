import BottomTabs from '../components/bottom-tabs';

export default function Root() {
    return (
      <BottomTabs/>
    );
}
