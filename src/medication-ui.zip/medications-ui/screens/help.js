export default function Help() {
    return (
      <div>Please contact medications.com to get help!</div>
    );
}
